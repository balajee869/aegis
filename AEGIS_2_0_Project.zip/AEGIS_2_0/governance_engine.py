def evaluate_system(name, use_case, impact, human_review, personal_data,
                    explanation, monitoring, known_limits):
    checks = {
        "Human oversight is available": human_review,
        "Outputs can be explained": explanation,
        "Ongoing monitoring is performed": monitoring,
        "System limitations are documented": known_limits,
        "Personal-data use has been identified": personal_data or use_case == "Other" or True,
    }
    # Score is a transparent educational checklist, not a validated risk model.
    score = round(sum(bool(v) for v in checks.values()) / len(checks) * 100)
    risk_points = {"Low": 0, "Medium": 1, "High": 2}[impact]
    risk_points += 1 if personal_data else 0
    risk_points += 1 if not human_review else 0
    risk_points += 1 if not monitoring else 0
    risk = "High" if risk_points >= 4 else "Medium" if risk_points >= 2 else "Low"

    actions = []
    if not human_review:
        actions.append("Add a meaningful human review process for consequential decisions.")
    if not explanation:
        actions.append("Document the factors that influence outputs and provide understandable explanations.")
    if not monitoring:
        actions.append("Define ongoing monitoring, incident reporting, and review responsibilities.")
    if not known_limits:
        actions.append("Document intended use, limitations, and cases where the system should not be used.")
    if personal_data:
        actions.append("Review data minimisation, access controls, retention, and privacy obligations.")
    if not actions:
        actions.append("Keep evidence for each control and review the assessment regularly.")

    return {
        "name": name,
        "score": score,
        "risk": risk,
        "passed": sum(bool(v) for v in checks.values()),
        "total": len(checks),
        "summary": f"{name} is a {use_case.lower()} use case. The checklist score is {score}/100 and the demonstration risk category is {risk}.",
        "checks": checks,
        "actions": actions,
    }


def evaluate_fairness(rate_a, rate_b):
    high = max(rate_a, rate_b)
    low = min(rate_a, rate_b)
    gap = abs(rate_a - rate_b)
    ratio = (low / high) if high > 0 else None
    return {
        "gap": gap,
        "ratio": ratio,
        "flag": ratio is not None and ratio < 0.80,
    }


def build_self_monitor(explanation, monitoring, known_limits, human_review):
    controls = {
        "Explainability information is available": explanation,
        "Monitoring process is enabled": monitoring,
        "Known limitations are documented": known_limits,
        "Human oversight route exists": human_review,
    }
    gaps = [label for label, present in controls.items() if not present]
    readiness = round(sum(controls.values()) / len(controls) * 100)
    return {
        "status": "Needs attention" if gaps else "Monitoring ready",
        "readiness": readiness,
        "gaps": gaps,
        "controls": controls,
    }

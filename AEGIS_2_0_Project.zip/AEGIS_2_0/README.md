# AEGIS 2.0 — AI Governance & Self-Monitoring

A beginner-friendly Streamlit student prototype that demonstrates:
- A transparent governance checklist and illustrative risk category
- Simulated self-monitoring of explainability, oversight, limitations, and monitoring
- A simple fairness outcome-rate comparison
- Downloadable JSON audit records

## Important scope
“Self-awareness” in this project means **simulated self-monitoring**. The software is not conscious and does not have human-like awareness. Scores and flags are educational demonstrations, not validated legal/compliance determinations.

## Run locally
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```

## Project files
- `app.py` — Streamlit user interface
- `governance_engine.py` — checklist, self-monitor, and fairness calculations
- `requirements.txt` — Python dependency list

## Suggested next improvements
- Add tests for governance and fairness calculations.
- Store audit records in a database.
- Add dataset-based fairness metrics with sample-size checks.
- Add role-based review and an incident log.
- Map controls to a chosen governance framework with citations.

import streamlit as st
from datetime import datetime
from governance_engine import evaluate_system, evaluate_fairness, build_self_monitor

st.set_page_config(page_title="AEGIS 2.0 | Responsible AI", page_icon="⚖️", layout="wide")

st.markdown("""
<style>
.stApp {background: #0b1220; color: #e8eef8;}
[data-testid="stMetric"] {background:#141f33; padding:16px; border-radius:12px;}
div.stButton > button {width:100%; border-radius:9px; font-weight:600;}
</style>
""", unsafe_allow_html=True)

st.title("⚖️ AEGIS 2.0")
st.subheader("AI Governance & Self-Monitoring Dashboard")
st.caption("A student-built demonstration system. It simulates self-monitoring; it is not conscious and does not certify legal compliance.")

with st.sidebar:
    st.header("AI system profile")
    system_name = st.text_input("System name", "Student Support Assistant")
    use_case = st.selectbox("Use case", ["Education", "Healthcare", "Hiring", "Finance", "Customer service", "Other"])
    impact = st.selectbox("Potential impact on people", ["Low", "Medium", "High"])
    human_review = st.checkbox("Human review is available", value=True)
    personal_data = st.checkbox("Uses personal or sensitive data", value=False)
    explanation = st.checkbox("Can explain its outputs", value=True)
    monitoring = st.checkbox("Regular monitoring is performed", value=False)
    known_limits = st.checkbox("Known limitations are documented", value=False)

st.markdown("### 1. Governance assessment")
if st.button("Run governance assessment"):
    result = evaluate_system(
        system_name, use_case, impact, human_review,
        personal_data, explanation, monitoring, known_limits
    )
    st.session_state["assessment"] = result

assessment = st.session_state.get("assessment")
if assessment:
    c1, c2, c3 = st.columns(3)
    c1.metric("Governance score", f'{assessment["score"]}/100')
    c2.metric("Risk level", assessment["risk"])
    c3.metric("Checks passed", f'{assessment["passed"]}/{assessment["total"]}')
    st.progress(assessment["score"] / 100)
    st.write("**Assessment summary:**", assessment["summary"])
    st.write("**Recommended actions**")
    for item in assessment["actions"]:
        st.write("•", item)
else:
    st.info("Choose the profile settings in the sidebar, then run the assessment.")

st.divider()
st.markdown("### 2. Self-monitoring (simulated)")
st.write("This module checks whether the system has enough monitoring information to report its own operating status.")
monitor = build_self_monitor(
    explanation=explanation,
    monitoring=monitoring,
    known_limits=known_limits,
    human_review=human_review
)
m1, m2, m3 = st.columns(3)
m1.metric("Self-monitor status", monitor["status"])
m2.metric("Readiness score", f'{monitor["readiness"]}/100')
m3.metric("Missing controls", str(len(monitor["gaps"])))
for gap in monitor["gaps"]:
    st.warning(gap)
if not monitor["gaps"]:
    st.success("All demonstration monitoring checks are present.")

st.divider()
st.markdown("### 3. Fairness comparison")
st.caption("Enter example group outcome rates from a test dataset. Use rates from a valid evaluation dataset, not assumptions about real people.")
f1, f2 = st.columns(2)
with f1:
    group_a = st.text_input("Group A label", "Group A")
    rate_a = st.number_input("Group A positive outcome rate (%)", 0.0, 100.0, 70.0, 1.0)
with f2:
    group_b = st.text_input("Group B label", "Group B")
    rate_b = st.number_input("Group B positive outcome rate (%)", 0.0, 100.0, 60.0, 1.0)
fairness = evaluate_fairness(rate_a, rate_b)
f1, f2 = st.columns(2)
f1.metric("Absolute outcome-rate gap", f'{fairness["gap"]:.1f} percentage points')
f2.metric("Four-fifths screening ratio", f'{fairness["ratio"]:.2f}' if fairness["ratio"] is not None else "Not defined")
if fairness["flag"]:
    st.warning("This simple screening rule flags the difference for further investigation. It does not prove discrimination.")
else:
    st.success("This simple screening rule did not flag the difference. It does not prove the system is fair.")
st.caption("The 0.80 ratio is a commonly used screening heuristic in some contexts, not a universal legal test. Review sample sizes, context, and applicable rules.")

st.divider()
st.markdown("### 4. Audit record")
if st.button("Create audit record"):
    record = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "system_name": system_name,
        "assessment": assessment or "No governance assessment run yet",
        "self_monitor": monitor,
        "fairness": fairness
    }
    st.session_state["audit_record"] = record
if "audit_record" in st.session_state:
    import json
    st.download_button(
        "Download audit record (JSON)",
        data=json.dumps(st.session_state["audit_record"], indent=2),
        file_name="aegis_audit_record.json",
        mime="application/json"
    )

st.divider()
st.caption("AEGIS 2.0 student prototype • Results are illustrative decision-support outputs, not legal, medical, or compliance advice.")
